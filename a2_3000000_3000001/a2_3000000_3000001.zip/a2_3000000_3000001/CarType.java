/**
 * @author Mehrdad Sabetzadeh, University of Ottawa
 * 
 *         The declaration of this enumeration is complete. You do *not* need to
 *         change this enumeration in this assignment.
 */
public enum CarType {
	ELECTRIC, SMALL, REGULAR, LARGE, NA;
}
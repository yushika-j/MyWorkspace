Yushika jhundoo 
300269830

lab1A
I tried running the code, It gives me build code errors.
Other than that, Arrays.sort doesnt give the expected output.